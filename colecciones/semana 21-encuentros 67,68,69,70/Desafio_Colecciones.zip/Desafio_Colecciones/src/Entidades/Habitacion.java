package Entidades;

import java.util.Date;
import java.util.HashMap;

public class Habitacion {
    private Integer noHab;
    private boolean fechaReserva;

}
