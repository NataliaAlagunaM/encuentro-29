import Services.ServicioMenu;
import Services.ServicioProducto;

public class Main {
    public static void main(String[] args) {
        ServicioMenu servicioMenu = new ServicioMenu();
        servicioMenu.inicializarMenu();
    }
}