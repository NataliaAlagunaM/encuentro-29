package Servicio;

import java.util.ArrayList;
import java.util.Collections;
import Entidad.Cliente;

public class ServicioCliente {
    private ArrayList<Cliente> clientes = new ArrayList<Cliente>();
    private int i = 0;
    private int vacio = -1;

    // registrarCliente: lo registra en el sistema.
    public void registrarCliente(Cliente c) {
        if (vacio != -1) {
            c.setId(vacio);
            vacio = -1;
            acomodarId();
        } else {
            c.setId(i);
            i++;
        }

        clientes.add(c);
    }

    public void sortt(){
        ArrayList <Integer> numero = new ArrayList<>();
        //int aux[] = new int [clientes.size()];
        for(int x = 0; x<clientes.size();x++){
            //aux[x] = clientes.get(x).getId();
            numero.add(clientes.get(x).getId());
        }
        Collections.sort(numero);
        int uno = numero.get(numero.size());
        


    }

    public void acomodarId() {

        for (int x = 0; x < clientes.size(); x++) {
            if (clientes.get(x).getId() != x) {
                vacio = x;
                break;
            }
        }
        i = clientes.size();

    }

    // obtenerClientes(): devuelve una lista con todos los clientes registrados en
    // el sistema.
    public ArrayList<Cliente> obtenerClientes() {
        return clientes;
    }

    // actualizarCliente(int id, String nombre, int edad, double altura, double
    // peso, String objetivo): recibe el identificador de un cliente existente y los
    // nuevos datos del cliente, y actualiza la información correspondiente en el
    // sistema.
    public void actualizarCliente(int id, String nombre, int edad, double altura, double peso, String objetivo,
            Cliente c) {

        c.setNombre(nombre);
        c.setId(id);
        c.setEdad(edad);
        c.setObjetivo(objetivo);
        c.setAltura(altura);
        c.setPeso(peso);
        acomodarId();
    }

    // eliminarCliente(int id): recibe el identificador de un cliente existente y lo
    // elimina del sistema.

    public void eliminarCliente(int id) {
        for (Cliente i : clientes) {
            if (i.getId() == id) {
                clientes.remove(i);
            }
        }
        acomodarId();

    }
}
