package Entidad;
public class Rutina {
    private int id, duracion;
    private String nombre, descripcion, nivelDificultad;
    
}
