import Entidad.Cliente;
import Servicio.ServicioCliente;

public class App {
    public static void main(String[] args) throws Exception {

        ServicioCliente sc = new ServicioCliente();

        Cliente c1 = new Cliente(25, "Pepito", "objetivo", 80.3, 80.3);
        sc.registrarCliente(c1);

        Cliente c2 = new Cliente(27, "juan", "obj", 1.93, 82.5);
        sc.registrarCliente(c2);

        Cliente c3 = new Cliente(27, "juan", "obj", 1.93, 82.5);
        sc.registrarCliente(c3);

        for (Cliente i : sc.obtenerClientes()) {
            System.out.println(i.toString());
        }

        System.out.println("----------------------------");
        sc.eliminarCliente(1);

        for (Cliente i : sc.obtenerClientes()) {
            System.out.println(i.toString());
        }
        System.out.println("----------------------------");
        Cliente c4 = new Cliente(28, "jasd", "aa", 1.22, 75.5);
        sc.registrarCliente(c4);

        for (Cliente i : sc.obtenerClientes()) {
            System.out.println(i.toString());
        }

        Cliente c5 = new Cliente(29, "test1", "aa", 1.22, 75.5);
        sc.registrarCliente(c5);

        Cliente c6 = new Cliente(30, "test2", "aa", 1.22, 75.5);
        sc.registrarCliente(c6);

        System.out.println("----------------------------");
        System.out.println("----------------------------");
        for (Cliente i : sc.obtenerClientes()) {
            System.out.println(i.toString());
        }
        sc.eliminarCliente(2);
        sc.eliminarCliente(4);

        System.out.println("----------------------------");
        System.out.println("----------------------------");
        for (Cliente i : sc.obtenerClientes()) {
            System.out.println(i.toString());
        }
    }
}
