/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.votacionegg;

import me.votacionegg.services.Simulador;

/**
 *
 * @author idmig
 */
public class VotacionEgg {

    public static void main(String[] args) {     
        
        System.out.println(Simulador.votacion().toString());
        
    }
}
