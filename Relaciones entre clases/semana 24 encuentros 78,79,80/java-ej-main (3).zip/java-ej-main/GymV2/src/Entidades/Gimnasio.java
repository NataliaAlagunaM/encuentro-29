package Entidades;

public class Gimnasio {

    public Gimnasio() {
    }
    
    
    
}
