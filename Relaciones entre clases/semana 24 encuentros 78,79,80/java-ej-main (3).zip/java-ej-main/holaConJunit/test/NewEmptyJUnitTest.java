/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//import holaconjunit.ClaseCalculadora.Calculadora;
//import holaconjunit.ClaseCalculadora.ValidadorDeContrasenias;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import holaconjunit.ClaseCalculadora.DiscountCalculator;

/**
 *
 * @author max72
 */
public class NewEmptyJUnitTest {
    
    public NewEmptyJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        
    }
    
    @After
    public void tearDown() {
    }
    
    @Test
    public void testDiscount(){
        //assertEquals(true,ValidadorDeContrasenias.validar("Almamora1$"));
        /*
        assertEquals(90,DiscountCalculator.estatica(100,10),0);
        System.out.println("Da bien porque es 90");
        assertEquals(0,DiscountCalculator.estatica(100,100),0);
        System.out.println("Da bien porque es 0");
        assertEquals(100,DiscountCalculator.estatica(100,0),0);
        System.out.println("Da bien porque es 100");
        */
    //System.out.println("Suma "+Calculadora.sumar(1, 2));
        //assertEquals(3, Calculadora.sumar(1, 2));
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
